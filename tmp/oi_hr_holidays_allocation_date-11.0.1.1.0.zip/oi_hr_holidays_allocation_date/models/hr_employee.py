'''
Created on Nov 4, 2018

@author: Zuhair Hammadi
'''
from odoo import models, api, fields
from odoo.tools import pycompat
from dateutil.relativedelta import relativedelta
from datetime import timedelta

class Employee(models.Model):
    _inherit= 'hr.employee'
    
    @api.multi
    def get_leave_balance(self, holiday_status_id, balance_date = None):
        self.ensure_one()
        if isinstance(holiday_status_id, models.BaseModel):
            holiday_status_id = holiday_status_id.id
        elif isinstance(holiday_status_id, pycompat.integer_types):
            pass
        elif isinstance(holiday_status_id, pycompat.string_types):
            holiday_status_id = self.env['hr.holidays.status'].search([('name','=', holiday_status_id)], limit = 1).id
            
        if not balance_date:
            balance_date = fields.Date.today()
                
        def duration(date1, date2):
            date1 = fields.Date.from_string(date1)
            date2 = fields.Date.from_string(date2)
            return (date2 - date1).days + 1
        
        balance = 0
        holidays = self.env['hr.holidays'].search([('employee_id','=', self.id), ('state', '=', 'validate'), ('holiday_status_id', '=', holiday_status_id), ('date_from', '<=', balance_date)])
        for holiday in holidays:
            if holiday.date_to <= balance_date:
                balance += holiday.number_of_days
            else:
                if holiday.type=='remove':
                    holiday_days = duration(holiday.date_from, holiday.date_to)
                    affected_days = duration(holiday.date_from, balance_date)
                    balance += holiday.number_of_days * (affected_days / holiday_days)
                else:
                    from_string = fields.Date.from_string
                    to_months = lambda delta : delta.years * 12 + delta.months + delta.days / 30
                    holiday_delta = relativedelta(from_string(holiday.date_to) + timedelta(days=1), from_string(holiday.date_from))
                    affected_delta = relativedelta(from_string(balance_date)  + timedelta(days=1), from_string(holiday.date_from))
                    balance += holiday.number_of_days * (to_months(affected_delta) / to_months(holiday_delta))
                
        return round(balance, 2)