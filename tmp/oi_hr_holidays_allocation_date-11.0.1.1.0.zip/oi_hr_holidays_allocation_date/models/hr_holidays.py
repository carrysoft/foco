'''
Created on Nov 4, 2018

@author: Zuhair Hammadi
'''
from odoo import models, api, _
from odoo.exceptions import ValidationError

class Holidays(models.Model):
    _inherit = "hr.holidays"
    
    @api.onchange('date_from')
    def _onchange_date_from(self):
        if self.type=='add':
            return
        return super(Holidays, self)._onchange_date_from()
    
    @api.onchange('date_to')
    def _onchange_date_to(self):
        if self.type=='add':
            return
        return super(Holidays, self)._onchange_date_to()            

    @api.constrains('date_from', 'date_to', 'holiday_status_id', 'employee_id', 'type', 'state')
    def _check_date(self):
        for holiday in self:
            domain = [
                ('date_from', '<=', holiday.date_to),
                ('date_to', '>=', holiday.date_from),
                ('id', '!=', holiday.id),
                ('type', '=', holiday.type),
                ('state', 'not in', ['cancel', 'refuse']),
            ]
            if holiday.holiday_type=='employee':
                domain.append(('employee_id','=', holiday.employee_id.id))
            else:
                domain.append(('category_id','=', holiday.category_id.id))
            if holiday.type == 'add':
                domain.append(('holiday_status_id','=', holiday.holiday_status_id.id))
            nholidays = self.search_count(domain)
            if nholidays:
                raise ValidationError(_('You can not have 2 leaves that overlaps on same day!'))
