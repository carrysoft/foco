# Leave Cancellation Request

Employees can request to cancel the approved Leaves.


### Depends
Addon depends on hr_holidays

### Tech

* [Python] - Models
* [XML] - Odoo views

### Installation
- www.odoo.com/documentation/10.0/setup/install.html

### Usage
> New menu under Leaves
> Approval is strictly followed the odoo basic flow.
> Menu for officers and managers to Approve
> Leaves become in refused state after approval of leave cancel requests.


License
----
GNU Affero General Public License (http://www.gnu.org/licenses/agpl.html)



