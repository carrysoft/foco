Changelog
=========
Version 0.9
-----------
* Initial Python 3 Support
* major changes

Version 0.8
-----------
* test suite tool (test_machine.py)
* Initial TCP support

Version 0.7
-----------
* internal major changes

Version 0.6
-----------
* device password support

Version 0.5
-----------
* bug fixed get_users bug

Version 0.4
-----------
* bug fixed
* minor update
* update documentation

Version 0.3
-----------
* add function `get_serialnumber` (return device serial number)
* add function `delete_user` (delete specific user by uid)
* add function `clear_data` (format device)
* add function `get_attendance` (get all attendance records)
* add function `clear_attendance` (clear all attendance records)

Version 0.2
------------
* add basic function and program fundamental
* configure pypi
* configure travis-ci integration

Version 0.1
-----------
* project initialization
