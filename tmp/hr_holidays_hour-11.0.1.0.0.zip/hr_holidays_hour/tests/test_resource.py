# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo.addons.resource.tests.test_resource import (  # noqa: F401
    TestIntervals, TestCalendarBasics, ResourceWorkingHours,
    TestWorkDays, TestResourceMixin
)
