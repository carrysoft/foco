Tests for `resource_calendar` are repeated from the Odoo SA standard module `resource`.
